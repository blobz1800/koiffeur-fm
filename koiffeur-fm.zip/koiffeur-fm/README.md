# Koiffeur FM

Custom firmware for the **M-VAVE FM-1** with a liquid-glass interface and a pixel koi pond that ripples with every note you play. Made by jemeruy.

It is built on [Felucca](https://github.com/hugelton/Felucca) 1.8.1 by Leo Kuroshita, so you keep all of Felucca's synth: 13 engines, the 64-step sequencer, the drum grid, SONG mode, MIDI, USB audio and the web editor. Koiffeur FM changes how the FM-1 looks and feels; the sound engine is untouched and passes all of Felucca's sound regression tests.

![Previews](docs/koiffeur-preview.png)

![The pond](docs/koiffeur-pond.gif)

## What's new

**Liquid glass (MENU › DISPLAY › STYLE › GLASS, the default)**
- Every screen sits on a pond of water: a slow gradient down the screen with caustic light across it.
- Cards, rows and panels are frosted glass. A little of the water and its light shows through, blurred.
- Every glass edge is lit: a bright top rim fading into a sheen, a lit left edge, softer light round the bottom and right, and a soft shadow on the water below.
- Selections and buttons get a glossy top.
- Layouts are exactly Felucca's. Text, icons and gauges are never touched by the glass pass, so everything stays as readable as FLAT.
- FLAT and LINE are still there in the same menu.

**The pond (MENU › DISPLAY › HOME › POND, the default on a fresh FM-1)**
- HOME's panel becomes a pixel-art koi pond in a glass frame. It holds three koi (a kohaku, an orange one and a gold one), lily pads, a lotus, and drifting caustic light.
- **Every note you play drops one ripple.** Its position follows the pitch (left to right) and the track (top to bottom). The ring is a lens: the koi and light under it bend, the crest is lit and the trough inside it is shaded.
- Each note also drops a pellet of food, and the nearest koi swims over and eats it.
- When nothing has played for a while, a few raindrops fall.
- It runs at 15 fps while you play and 8 fps when idle, to save battery. MENU › ANIM OFF stops it.

**Warm palettes (MENU › DISPLAY › COLOR):** KOI (the default: deep pond water, koi orange, paper cream, lantern gold), LANTERN and DUSK. All of Felucca's palettes are still there. In GREY and MONO the pond is drawn in grays.

**Splash:** a glass card on the water, with a kohaku and an orange koi circling in one ripple, the version, and "made by jemeruy". ABOUT keeps Felucca's credits and licence notices.

## Install

> Custom firmware is installed at your own risk. **Back up first.** The installer saves your projects, sounds, samples and settings, and offers **Return to official V15** (you need M-VAVE's original `FM-1.fwsc`).

**Browser (easiest).** Open the installer page this repository publishes (see *Build* below) in **Chrome or Edge**. Connect the FM-1 by USB and follow the steps. It is Felucca's installer, rebranded and carrying Koiffeur's package.

**Command line.**
```
pip install mido python-rtmidi
python3 tools/fm1_install.py koiffeur-fm-1.0.fwsc
```
To go back: `python3 tools/fm1_install.py FM-1.fwsc` with M-VAVE's official file, or use M-VAVE's own updater.

**Coming from Felucca:** your settings and music carry over. Your palette stays as you had it (pick KOI in COLOR), and STYLE becomes GLASS.

## Build

The FM-1's compiler is JieLi's Linux toolchain, downloaded from JieLi.

**On GitHub (no setup).** Put this folder in a GitHub repository and push. The workflow in `.github/workflows/build.yml`:
1. fetches the toolchain and the JieLi AC79 SDK;
2. builds `koiffeur-fm-1.0.fwsc`;
3. attaches it to the run as the **koiffeur-fm** artifact (Actions tab, click the run);
4. publishes the browser installer to GitHub Pages. Turn this on once under *Settings › Pages › Source: GitHub Actions*.

Change the version in `KOI_VERSION` at the top of the workflow.

**On a Mac.** Install Docker Desktop, then run:
```
pip3 install Pillow fonttools
tools/get_toolchain.sh
git clone --depth 1 --branch AC79NN_SDK_V1.2.1_2023-12-13 \
    https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK.git ~/fw-AC79_AIoT_SDK
./build.sh --release 1.0            # build/koiffeur-fm-1.0.fwsc
```
On Linux x86-64 the same works without Docker. See [BUILDING.md](BUILDING.md) for details.

**Previews and tests without hardware.** `tests/run_tests.sh` runs Felucca's host suites plus Koiffeur's:
- every screen in every palette drawn in GLASS and linted for clipped, overlapping or misaligned text;
- grayscale palettes checked to stay gray;
- pond filmstrips.

PNGs land in `build/ui_new/GLASS/` and `build/ui_new/POND/`.

## What changed, for the curious

| File | Change |
| --- | --- |
| `firmware/src/gfx.c` | The glass pass: water and frosted glass mapped from marker colours as each canvas strip goes to the panel, rims from the recorded `cv_rrect` cells, and `lcd_fill` of the background drawn as water. |
| `firmware/src/ui_pond.c` | New: the pond, the koi, the ripple lens and the splash koi. |
| `firmware/src/voice.c` | A lock-free ring of note-ons for the pond. |
| `firmware/src/ui_draw.c`, `menu_items.c`, `settings_persist.c`, `ui.c`, `panel.c` | STYLE GLASS, HOME POND, defaults, splash, ABOUT. |
| `tools/gen_glass.py` | New: the tileable caustic textures. |
| `tools/gen_ui_palettes.py` | KOI, LANTERN and DUSK (all pass the WCAG contrast checks). |
| `tests/` | GLASS and POND renders; tests updated for the three-way STYLE, four HOME views and 13 palettes. |

Package identity: `FM-1_970` (`FM-1_97Y` for release 1.Y), so it never clashes with Felucca's `FM-1_9XY`.

## Licence and credits

GPL-3.0-only, as Felucca. Koiffeur FM is a modified version of Felucca by Leo Kuroshita (Hügelton Instruments). The engines, the hardware layer, fonts, icons and samples keep their own licences: see [CREDITS.md](CREDITS.md), [LICENSING.md](LICENSING.md) and [LICENSES/](LICENSES/). Felucca's original README is in [README-Felucca.md](README-Felucca.md).

M-VAVE and FM-1 are trademarks of their owners. Koiffeur FM is not affiliated with or supported by M-VAVE or Hügelton Instruments.
