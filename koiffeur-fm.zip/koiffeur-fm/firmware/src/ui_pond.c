/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 jemeruy (Koiffeur FM) */
/* The pond: MENU > DISPLAY > HOME POND, in HOME's panel in place of the scope (ui_graph.c draw_graph), and the splash's
 * koi (ui_draw.c draw_splash).
 *
 * A pixel-art pond at 2 x 2 screen pixels a pond pixel, 114 x 58 of them in the panel's glass frame:
 *   water   the palette's background deepened toward pond green, a gradient down, the caustic light of the GLASS style
 *           (ui_glass.h GL_CAU) drifting slowly across the floor;
 *   koi     three, each a spine of KS points that follows its head (a chain: every point keeps SEG behind the one
 *           before), drawn as circles along it with pectoral fins and a tail fan; a kohaku, an orange and a gold one.
 *           They wander, turn away from the banks, and go for the food;
 *   pads    three lily pads (one with a lotus) float on top; koi pass under them; everything below casts a soft shadow;
 *   notes   every note played (voice.c trk_note_on: pond_q*) drops a pellet of food where its pitch (across) and track
 *           (down) put it, and one ripple: a single ring that grows and fades. The ring is a lens: the pond under it is
 *           read from a little further in or out along the ring's radius (the koi and the caustics bend), its crest
 *           lit and the trough inside it shaded. The nearest koi swims for the pellet and eats it.
 *   rain    with nothing played for a while, now and then a drop.
 * Everything is computed per pond pixel from the state (no frame buffer); the ring's square-root only in its band.
 * MENU > ANIM OFF: the pond stands still. */

#define PD_W 114                         /* pond pixels */
#define PD_H 58
#define PD_X0 6                          /* on the panel's canvas (240 x H_GRAPH): x 6..233, y 3..118 */
#define PD_Y0 3
#define KS 8                             /* spine points of a koi */
#define SEG 25                           /* their spacing, 1/16 pond px */
#define NKOI 3
#define NRIP 6
#define NFOOD 6
#define RIP_MS 1250u                     /* a ripple's life */
#define RIP_SPEED 26                     /* its ring's growth, pond px per second */

static const int16_t POND_SIN[64] = {      /* sin, Q12, a quarter wave in 64 steps (pond_sin: the whole circle in 256) */
    0, 101, 201, 301, 401, 501, 601, 700, 799, 897, 995, 1092, 1189, 1285, 1380, 1474, 1567, 1660, 1751, 1842, 1931,
    2019, 2106, 2191, 2276, 2359, 2440, 2520, 2598, 2675, 2751, 2824, 2896, 2967, 3035, 3102, 3166, 3229, 3290, 3349,
    3406, 3461, 3513, 3564, 3612, 3659, 3703, 3745, 3784, 3822, 3857, 3889, 3920, 3948, 3973, 3996, 4017, 4036, 4052,
    4065, 4076, 4085, 4091, 4095};
static int32_t pond_sin(int32_t a)          /* a: 0..255 a turn */
{
    a &= 255;
    if (a < 64) return POND_SIN[a];
    if (a < 128) return POND_SIN[127 - a];
    if (a < 192) return -POND_SIN[a - 128];
    return -POND_SIN[255 - a];
}
static int32_t pond_cos(int32_t a) { return pond_sin(a + 64); }
static uint32_t pond_isqrt(uint32_t v)
{
    uint32_t r = 0, b = 1u << 30;
    while (b > v) b >>= 2;
    while (b) {
        if (v >= r + b) { v -= r + b; r = (r >> 1) + b; }
        else r >>= 1;
        b >>= 2;
    }
    return r;
}
static int32_t pd_atan2(int32_t y, int32_t x)    /* 0..255 a turn, coarse (an octant and a ratio): steering only */
{
    int32_t ax = x < 0 ? -x : x, ay = y < 0 ? -y : y, a;
    if (!ax && !ay) return 0;
    a = ax >= ay ? 32 * ay / ax : 64 - 32 * ax / ay;   /* 0..64 in the first quadrant */
    if (x < 0) a = 128 - a;
    if (y < 0) a = 256 - a;
    return a & 255;
}

typedef struct {
    int32_t x[KS], y[KS];                /* 1/16 pond px; [0] the head */
    int32_t ang, turn, spd;              /* heading 0..255 (x 16: 1/16 steps), its drift; speed 1/16 px per second */
    int32_t fx, fy;                      /* the moves' remainders (1/16 px x 4096000) */
    int8_t food;                         /* the pellet it swims for, -1 none */
    uint8_t kind;                        /* 0 kohaku, 1 orange, 2 gold */
} koi_t;
static struct {
    koi_t k[NKOI];
    struct { int16_t x, y; uint32_t t0; uint8_t amp; } rip[NRIP];   /* x, y: pond px x 16 */
    struct { int16_t x, y; uint8_t on; } food[NFOOD];
    uint32_t last, rnd, quiet, gen;
    uint8_t qr, ready;
    uint16_t water[4][16];               /* the water by depth band and caustic level (unswapped) */
    uint16_t sun, crest, pad, pad2, padrim, lotus, lotus2, pellet, eye;
    uint16_t body[3][2], fin[3];         /* per kind: the base colour and its patches; the fins */
} pd;

static uint32_t pd_rand(void)
{
    pd.rnd = pd.rnd * 1664525u + 1013904223u;
    return pd.rnd >> 8;
}

static void pd_colours(void)
{
    static const uint8_t KOI_RGB[3][2][3] = {{{246, 242, 232}, {232, 70, 40}},     /* kohaku: white, red patches */
                                        {{255, 128, 52}, {255, 236, 220}},    /* orange, a white head */
                                        {{255, 200, 86}, {255, 230, 150}}};   /* gold, paler */
    uint32_t b, k;
    uint16_t teal = RGB(34, 96, 92), deep, top;
    pd.sun = ux_mix(ux_mix(ux.text, ux.accent, 30), 0xFFFF, 20);
    top = ux_mix(ux.light ? RGB(40, 90, 96) : ux.bg, teal, ux.light ? 30 : 42);
    deep = ux_mix(top, 0x0000, 55);
    pd.crest = ux_mix(pd.sun, RGB(200, 244, 236), 40);       /* a ring's lit crest: bright, a little cool */
    for (b = 0; b < 4u; b++) {
        uint16_t w = ux_mix(top, deep, (int32_t)(b * 100u / 3u));
        for (k = 0; k < 16u; k++)
            pd.water[b][k] = ux_mix(w, pd.sun, (int32_t)(k * 24u / 15u));
    }
    pd.pad = RGB(70, 150, 84); pd.pad2 = RGB(46, 112, 64); pd.padrim = RGB(132, 196, 118);
    pd.lotus = RGB(250, 172, 200); pd.lotus2 = RGB(255, 236, 244); pd.pellet = RGB(214, 170, 110);
    pd.eye = RGB(30, 24, 22);
    for (k = 0; k < 3u; k++) {
        pd.body[k][0] = RGB(KOI_RGB[k][0][0], KOI_RGB[k][0][1], KOI_RGB[k][0][2]);
        pd.body[k][1] = RGB(KOI_RGB[k][1][0], KOI_RGB[k][1][1], KOI_RGB[k][1][2]);
        pd.fin[k] = ux_mix(pd.body[k][0], 0xFFFF, 62);       /* pale, seen half through (pd_under) */
    }
    if (settings.palette == UI_GREY_INDEX || settings.palette == UI_BW_INDEX) {   /* the gray palettes: the pond in grays */
        uint16_t *all[] = {&pd.sun, &pd.crest, &pd.pad, &pd.pad2, &pd.padrim, &pd.lotus, &pd.lotus2, &pd.pellet, &pd.eye,
                           &pd.body[0][0], &pd.body[0][1], &pd.body[1][0], &pd.body[1][1], &pd.body[2][0], &pd.body[2][1],
                           &pd.fin[0], &pd.fin[1], &pd.fin[2]};
        for (k = 0; k < NELEM(all); k++)
            *all[k] = ux_gray(ux_luma(*all[k]) * 31u / 255u);
        for (b = 0; b < 64u; b++)
            pd.water[b >> 4][b & 15u] = ux_gray(ux_luma(pd.water[b >> 4][b & 15u]) * 31u / 255u);
    }
    pd.gen = ux.gen;
}

static void pd_koi_place(koi_t *k, int32_t x, int32_t y, int32_t ang)
{
    uint32_t i;
    k->ang = ang * 16;
    for (i = 0; i < KS; i++) {
        k->x[i] = x * 16 - pond_cos(ang) * SEG * (int32_t)i / 4096;
        k->y[i] = y * 16 - pond_sin(ang) * SEG * (int32_t)i / 4096;
    }
    k->food = -1;
    k->spd = 90;
}

static void pd_init(void)
{
    uint32_t i;
    pd.rnd = 0x6B6F69u;
    for (i = 0; i < NKOI; i++) {
        pd.k[i].kind = (uint8_t)i;
        pd_koi_place(&pd.k[i], 24 + (int32_t)i * 34, 18 + (int32_t)(i % 2u) * 20, (int32_t)(i * 90u + 20u));
    }
    pd.qr = pond_qw;
    pd.ready = 1;
}

/* the lily pads: centre, radius, the notch's direction (0..255), a lotus */
static const struct { int8_t x, y, r, notch, lotus; } PADS[3] = {{14, 11, 7, 40, 0}, {96, 43, 8, 170, 1}, {103, 9, 4, 100, 0}};

static void pd_ripple(int32_t x, int32_t y, uint32_t amp)
{
    uint32_t i, j = 0, old = 0;
    for (i = 0; i < NRIP; i++) {                 /* a free one, else the oldest */
        uint32_t age = fm1_ms - pd.rip[i].t0;
        if (!pd.rip[i].amp || age >= RIP_MS) { j = i; break; }
        if (age > old) { old = age; j = i; }
    }
    pd.rip[j].x = (int16_t)(x * 16);
    pd.rip[j].y = (int16_t)(y * 16);
    pd.rip[j].t0 = fm1_ms;
    pd.rip[j].amp = (uint8_t)(amp > 255u ? 255u : amp);
}

static void pd_note(uint32_t note, uint32_t k, uint32_t vel)
{
    int32_t x = 6 + ((int32_t)note - 24) * 102 / 84, y = 9 + (int32_t)(k & 3u) * 12 + (int32_t)((note * 7u) % 9u) - 4;
    uint32_t i, best = 0;
    int32_t bd = 0x7FFFFFFF;
    x = clamp(x, 4, PD_W - 5);
    y = clamp(y, 4, PD_H - 5);
    pd_ripple(x, y, 110u + vel);
    for (i = 0; i < NFOOD && pd.food[i].on; i++)
        ;
    if (i == NFOOD)
        i = pd_rand() % NFOOD;
    pd.food[i].x = (int16_t)(x * 16);
    pd.food[i].y = (int16_t)(y * 16);
    pd.food[i].on = 1;
    for (k = 0; k < NKOI; k++) {                 /* the nearest koi with nothing to eat goes for it */
        int32_t dx = pd.k[k].x[0] / 16 - x, dy = pd.k[k].y[0] / 16 - y, d = dx * dx + dy * dy;
        if (pd.k[k].food < 0 && d < bd) { bd = d; best = k; }
    }
    if (bd != 0x7FFFFFFF)
        pd.k[best].food = (int8_t)i;
}

static void pd_step(uint32_t dt)
{
    uint32_t i, j;
    for (i = 0; i < NKOI; i++) {
        koi_t *k = &pd.k[i];
        int32_t hx = k->x[0], hy = k->y[0], want = -1, a = k->ang / 16, goal = 90;
        if (k->food >= 0 && !pd.food[k->food].on)
            k->food = -1;
        if (k->food >= 0) {                      /* for the pellet */
            int32_t dx = pd.food[k->food].x - hx, dy = pd.food[k->food].y - hy;
            want = pd_atan2(dy, dx);
            goal = 230;
            if (dx * dx + dy * dy < 40 * 40) {   /* eaten: a little splash */
                pd.food[k->food].on = 0;
                pd_ripple(pd.food[k->food].x / 16, pd.food[k->food].y / 16, 45u);
                k->food = -1;
            }
        } else {                                 /* wander */
            k->turn += (int32_t)(pd_rand() % 9u) - 4;
            k->turn = clamp(k->turn, -24, 24);
        }
        if (hx < 10 * 16 || hx > (PD_W - 10) * 16 || hy < 8 * 16 || hy > (PD_H - 8) * 16)
            if (want < 0) want = pd_atan2(PD_H * 8 - hy, PD_W * 8 - hx);   /* away from the bank */
        if (want >= 0) {
            int32_t d = ((want - a + 128) & 255) - 128;
            k->turn = clamp(d * 3, -60, 60);
        }
        k->ang = (k->ang + k->turn * (int32_t)dt / 40) & 4095;
        k->spd += (goal - k->spd) * (int32_t)dt / 400;
        a = k->ang / 16;
        k->fx += pond_cos(a) * k->spd * (int32_t)dt;          /* (Q12 x 1/16 px/s x ms: 4096000 a 1/16 px) */
        k->fy += pond_sin(a) * k->spd * (int32_t)dt;
        k->x[0] = clamp(hx + k->fx / 4096000, 2 * 16, (PD_W - 2) * 16);
        k->y[0] = clamp(hy + k->fy / 4096000, 2 * 16, (PD_H - 2) * 16);
        k->fx %= 4096000;
        k->fy %= 4096000;
        for (j = 1; j < KS; j++) {               /* the body follows */
            int32_t dx = k->x[j - 1] - k->x[j], dy = k->y[j - 1] - k->y[j];
            uint32_t l = pond_isqrt((uint32_t)(dx * dx + dy * dy));
            if (l > SEG) {
                k->x[j] = k->x[j - 1] - dx * SEG / (int32_t)l;
                k->y[j] = k->y[j - 1] - dy * SEG / (int32_t)l;
            }
        }
    }
}

/* the koi's circles this frame (pond px x 16; r2 in px^2 x 256) */
#define KC_N (KS + 5)
static struct { int32_t x, y, r2; uint16_t c; uint8_t fin; } kc[NKOI][KC_N];
static int32_t kbb[NKOI][4];
static uint64_t pd_krows, pd_frows;      /* this frame: the pond rows a koi (or its shadow) / a pellet can touch */
static void pd_shapes(void)
{
    static const uint8_t R[KS] = {30, 40, 44, 42, 36, 28, 20, 14};   /* radius, 1/16 px */
    uint32_t i, j;
    for (i = 0; i < NKOI; i++) {
        koi_t *k = &pd.k[i];
        int32_t n = 0, tx, ty, l, px, py;
        int32_t x0 = 0x7FFFFFF, y0 = 0x7FFFFFF, x1 = -0x7FFFFFF, y1 = -0x7FFFFFF;
        for (j = 0; j < KS; j++) {
            uint16_t c = pd.body[k->kind][0];
            if (k->kind == 0 && (j == 2 || j == 3 || j == 5 || j == 0)) c = pd.body[0][1];   /* kohaku's patches */
            if (k->kind == 1 && j == 0) c = pd.body[1][1];
            if (k->kind == 2 && (j & 1u)) c = pd.body[2][1];
            kc[i][n].x = k->x[j]; kc[i][n].y = k->y[j]; kc[i][n].r2 = R[j] * R[j]; kc[i][n].c = c; kc[i][n].fin = 0; n++;
        }
        tx = k->x[KS - 2] - k->x[KS - 1]; ty = k->y[KS - 2] - k->y[KS - 1];   /* the tail's direction (backwards) */
        l = (int32_t)pond_isqrt((uint32_t)(tx * tx + ty * ty)); if (!l) l = 1;
        px = -ty * 22 / l; py = tx * 22 / l;                                  /* across it */
        kc[i][n].x = k->x[KS - 1] - tx * 22 / l + px; kc[i][n].y = k->y[KS - 1] - ty * 22 / l + py;
        kc[i][n].r2 = 20 * 20; kc[i][n].c = pd.fin[k->kind]; kc[i][n].fin = 1; n++;
        kc[i][n].x = k->x[KS - 1] - tx * 22 / l - px; kc[i][n].y = k->y[KS - 1] - ty * 22 / l - py;
        kc[i][n].r2 = 20 * 20; kc[i][n].c = pd.fin[k->kind]; kc[i][n].fin = 1; n++;
        tx = k->x[0] - k->x[2]; ty = k->y[0] - k->y[2];
        l = (int32_t)pond_isqrt((uint32_t)(tx * tx + ty * ty)); if (!l) l = 1;
        px = -ty * 46 / l; py = tx * 46 / l;
        kc[i][n].x = k->x[1] + px; kc[i][n].y = k->y[1] + py; kc[i][n].r2 = 18 * 18; kc[i][n].c = pd.fin[k->kind]; kc[i][n].fin = 1; n++;
        kc[i][n].x = k->x[1] - px; kc[i][n].y = k->y[1] - py; kc[i][n].r2 = 18 * 18; kc[i][n].c = pd.fin[k->kind]; kc[i][n].fin = 1; n++;
        kc[i][n].x = k->x[0] + tx * 14 / l + px / 3; kc[i][n].y = k->y[0] + ty * 14 / l + py / 3;   /* an eye */
        kc[i][n].r2 = 7 * 7; kc[i][n].c = pd.eye; kc[i][n].fin = 2; n++;
        for (j = 0; j < (uint32_t)n; j++) {
            x0 = kc[i][j].x < x0 ? kc[i][j].x : x0; x1 = kc[i][j].x > x1 ? kc[i][j].x : x1;
            y0 = kc[i][j].y < y0 ? kc[i][j].y : y0; y1 = kc[i][j].y > y1 ? kc[i][j].y : y1;
        }
        kbb[i][0] = x0 - 48; kbb[i][1] = y0 - 48; kbb[i][2] = x1 + 48; kbb[i][3] = y1 + 48;
    }
    pd_krows = pd_frows = 0;
    for (i = 0; i < NKOI; i++) {
        int32_t y, ya = kbb[i][1] / 16 - 1, yb = (kbb[i][3] + 56) / 16 + 1;   /* (+ the shadow's offset) */
        for (y = ya < 0 ? 0 : ya; y <= yb && y < PD_H; y++)
            pd_krows |= (uint64_t)1u << y;
    }
    for (i = 0; i < NFOOD; i++)
        if (pd.food[i].on && pd.food[i].y / 16 < PD_H)
            pd_frows |= (uint64_t)1u << (pd.food[i].y / 16);
}

/* a koi at pond pixel (x, y) (its centre, x 16): its colour, 0 none; a fin returns 1 in *fin */
static uint16_t pd_koi_at(int32_t x, int32_t y, int *fin)
{
    uint32_t i, j;
    for (i = 0; i < NKOI; i++) {
        uint16_t c = 0;
        if (x < kbb[i][0] || x > kbb[i][2] || y < kbb[i][1] || y > kbb[i][3])
            continue;
        for (j = 0; j < KC_N; j++) {             /* the later circles over the earlier: eye over head */
            int32_t dx = x - kc[i][j].x, dy = y - kc[i][j].y;
            if (dx * dx + dy * dy <= kc[i][j].r2) {
                if (kc[i][j].fin == 1 && c) continue;     /* (a fin under the body) */
                c = kc[i][j].c;
                *fin = kc[i][j].fin == 1;
            }
        }
        if (c)
            return c;
    }
    return 0;
}

/* the pond under the surface at pond pixel (x, y), x 16 (koi, their shadows, the water) */
static uint16_t pd_under(int32_t x, int32_t y, uint32_t now)
{
    int fin = 0;
    int32_t ry = y >> 4;
    int koi_row = ry >= 0 && ry < PD_H && ((pd_krows >> ry) & 1u);
    uint16_t c = koi_row ? pd_koi_at(x, y, &fin) : 0;
    static const uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
    int32_t px = x >> 4, py = y >> 4, b = clamp(py, 0, PD_H - 1) * 3 * 16 / (PD_H - 1);   /* depth, 1/16 bands */
    uint32_t band = (uint32_t)(b >> 4), lv, cx = (uint32_t)(px + (int32_t)(now / 90u)), cy = (uint32_t)(py + (int32_t)(now / 170u));
    uint16_t w;
    if (c && !fin)
        return c;
    if ((uint32_t)(b & 15) > BAYER[(py & 3) * 4 + (px & 3)] && band < 3u)   /* dithered between the bands (pixel art) */
        band++;
    lv = gl_lvl(GL_CAU, cx, cy);
    lv = lv > 9u ? lv - 3u : (lv * 2u) / 3u + (gl_lvl(GL_CAUB, cx + 40u, cy) >> 2);   /* (soft: the blurred light under it) */
    w = pd.water[band][lv];
    if (c)                                       /* a fin: half seen */
        return ux_mix(w, c, 55);
    if (koi_row && pd_koi_at(x - 40, y - 56, &fin))   /* a koi's shadow on the floor */
        return ux_mix(w, 0x0000, 30);
    return w;
}

/* on the surface: a pad, a lotus, a pellet (0: nothing) */
static uint16_t pd_surface(int32_t px, int32_t py, int *shadow)
{
    uint32_t i;
    for (i = 0; i < 3u; i++) {
        int32_t dx = px - PADS[i].x, dy = py - PADS[i].y, d2, r = PADS[i].r;
        if (dx > r + 2 || dx < -r || dy > r + 3 || dy < -r)
            continue;
        d2 = dx * dx + dy * dy;
        if (d2 <= r * r) {
            int32_t a = pd_atan2(dy, dx), da = ((a - PADS[i].notch + 128) & 255) - 128;
            if (da > -12 && da < 12 && d2 > 2)
                continue;                        /* the notch */
            if (PADS[i].lotus && d2 <= 5)
                return d2 <= 1 ? pd.lotus2 : pd.lotus;
            if (d2 >= (r - 1) * (r - 1)) return pd.padrim;
            return ((dx + dy) & 3) == 0 && d2 > 4 ? pd.pad2 : pd.pad;   /* a vein */
        }
        dx -= 1; dy -= 2;
        if (dx * dx + dy * dy <= r * r) *shadow = 1;
    }
    if ((pd_frows >> py) & 1u)
        for (i = 0; i < NFOOD; i++)
            if (pd.food[i].on && px == pd.food[i].x / 16 && py == pd.food[i].y / 16)
                return pd.pellet;
    return 0;
}

/* the pond, pond px (lw x lh) at canvas (x0, y0), 2 x 2 each */
static void pd_paint(int32_t x0, int32_t y0, uint32_t now)
{
    int32_t px, py;
    for (py = 0; py < PD_H; py++) {
        uint16_t *r0 = cv_px + (uint32_t)(y0 + py * 2) * cv_w + (uint32_t)x0, *r1 = r0 + cv_w;
        for (px = 0; px < PD_W; px++) {
            int32_t sx = px * 16 + 8, sy = py * 16 + 8, shade = 0;
            uint32_t i;
            int sh = 0;
            uint16_t c, s;
            if ((px < 2 || px >= PD_W - 2) && (py < 2 || py >= PD_H - 2) &&
                (px == 0 || px == PD_W - 1 || py == 0 || py == PD_H - 1))
                continue;                        /* (rounded corners: the glass shows) */
            for (i = 0; i < NRIP; i++) {         /* the ring: a lens and its light */
                uint32_t age = now - pd.rip[i].t0;
                int32_t r, dx, dy, d2, lo, hi, d, f, off;
                if (!pd.rip[i].amp || age >= RIP_MS) continue;
                r = (int32_t)(age * RIP_SPEED * 16u / 1000u);
                dx = sx - pd.rip[i].x; dy = sy - pd.rip[i].y;
                if (dx > r + 64 || dx < -r - 64 || dy > r + 64 || dy < -r - 64) continue;
                d2 = dx * dx + dy * dy;
                lo = r - 64; hi = r + 40;
                if (d2 > hi * hi || (lo > 0 && d2 < lo * lo)) continue;
                d = (int32_t)pond_isqrt((uint32_t)d2);
                if (!d) d = 1;
                f = (int32_t)pd.rip[i].amp * (int32_t)(RIP_MS - age) / (int32_t)RIP_MS;   /* 0..255 */
                off = (r - d) * f / 255 * 3 / 2;                     /* the lens: read from along the radius */
                sx += dx * off / d; sy += dy * off / d;
                if (d >= r - 8 && d <= r + 16) shade += f;            /* the crest: one pond px */
                else if (d < r - 8 && d >= r - 40) shade -= f / 2;    /* the trough just inside it */
            }
            c = pd_surface(px, py, &sh);
            if (!c) {
                c = pd_under(sx, sy, now);
                if (sh) c = ux_mix(c, 0x0000, 28);
            }
            if (shade > 0) c = ux_mix(c, pd.crest, clamp(shade * 70 / 255, 0, 75));
            else if (shade < 0) c = ux_mix(c, 0x0000, clamp(-shade * 32 / 255, 0, 32));
            if (c == ux.bg || c == ux.surf) c ^= 0x0841u;         /* never a glass marker (gray stays gray) */
            s = swap16(c);
            r0[px * 2] = r0[px * 2 + 1] = r1[px * 2] = r1[px * 2 + 1] = s;
        }
    }
}

/* HOME's panel, a frame (ui_graph.c draw_graph: on HOME POND, every other frame) */
static void graph_pond(void)
{
    uint32_t now = fm1_ms, dt, i;
    if (!pd.ready) pd_init();
    if (pd.gen != ux.gen) pd_colours();
    dt = now - pd.last;
    pd.last = now;
    if (dt > 200u) dt = 200u;
    while (pd.qr != pond_qw) {                   /* the notes since the last frame */
        uint32_t k = pd.qr & 7u;
        pd_note(pond_qn[k], pond_qk[k], pond_qv[k]);
        pd.qr = (uint8_t)(pd.qr + 1u);
        pd.quiet = now;
    }
    if (ui_prefs & PREF_ANIM_OFF) {              /* MENU > ANIM OFF: still */
        dt = 0;
        now = pd.quiet;
    }
    if (dt && now - pd.quiet > 9000u && pd_rand() % 1000u < dt * 2u / 5u)   /* rain, quietly */
        pd_ripple((int32_t)(4u + pd_rand() % (PD_W - 8u)), (int32_t)(4u + pd_rand() % (PD_H - 8u)), 60u + pd_rand() % 50u);
    for (i = 0; dt && i < dt; i += 20u)          /* (steps of 20 ms: the chain keeps up) */
        pd_step(dt - i < 20u ? dt - i : 20u);
    pd_shapes();
    pd_paint(PD_X0, PD_Y0, now);
}

/* the splash's koi (ui_draw.c splash_glass): a kohaku and an orange koi chasing each other round one ring, in the pond's
 * own pixels (2 x 2 screen px), on the glass square's canvas (176 wide; this canvas holds the square's rows oy..). Only
 * the koi, their shadows and the ring are drawn: the rest stays the square's glass */
#define SPK_CX 44                         /* the pair's centre in the square, pond px (screen 88, 100) */
#define SPK_CY 50
#define SPK_R 12                          /* their circle, pond px */
static void pond_splash_art(int32_t oy)
{
    int32_t x, y, i, j;
    uint16_t ssf = swap16(ux.surf);
    pd_colours();
    for (i = 0; i < NKOI; i++) {                 /* two on the circle, opposite; the third away */
        koi_t *k = &pd.k[i];
        int32_t a0 = i == 0 ? 20 : 148;
        k->kind = (uint8_t)(i == 0 ? 0 : 1);
        for (j = 0; j < KS; j++) {
            int32_t a = a0 - j * 8;
            k->x[j] = SPK_CX * 16 + pond_cos(a) * SPK_R * 16 / 4096 + (i > 1 ? 99999 : 0);
            k->y[j] = SPK_CY * 16 + pond_sin(a) * SPK_R * 16 / 4096;
        }
    }
    pd_shapes();
    for (y = 0; y < (int32_t)cv_h; y++) {
        int32_t py = (y + oy) / 2;               /* pond px in the square */
        uint16_t *row = cv_px + (uint32_t)y * cv_w;
        for (x = 0; x < (int32_t)cv_w; x++) {
            int32_t px = x / 2, dx = px - SPK_CX, dy = py - SPK_CY, d2 = dx * dx + dy * dy;
            int fin = 0, f2 = 0;
            uint16_t c = pd_koi_at(px * 16 + 8, py * 16 + 8, &fin), s;
            if (row[x] != ssf)
                continue;                        /* (only on the glass: not the text, not the rim) */
            if (c && fin)
                c = ux_mix(gl_milk, c, 60);
            if (!c) {
                int32_t ro = SPK_R + 7;
                if (d2 >= ro * ro && d2 < (ro + 1) * (ro + 1)) c = ux_mix(gl_milk, pd.crest, 75);       /* the ring */
                else if (d2 >= (ro - 1) * (ro - 1) && d2 < ro * ro) c = ux_mix(gl_milk, 0x0000, 20);  /* its trough */
                else if (pd_koi_at(px * 16 + 8 - 16, py * 16 + 8 - 24, &f2) && !f2) c = ux_mix(gl_milk, 0x0000, 24);
            }
            if (!c) continue;
            if (c == ux.bg || c == ux.surf) c ^= 0x0841u;
            s = swap16(c);
            row[x] = s;
        }
    }
    pd.ready = 0;                                /* (HOME's pond starts afresh) */
}
